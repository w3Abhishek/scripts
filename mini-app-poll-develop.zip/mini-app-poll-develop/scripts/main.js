var LOAD_DATA = null;

function UUID() {}

UUID.randomUUID = function () {
  randomBytes = new Int8Array(16);
  for (var index = 0; index < 16; index++) {
    randomBytes[index] = Math.random() * 10000;
  }
  return randomBytes;
};

// Function to send message to native and get the appropriate callback triggered
const sendToNative = (type, callback, content) => {
  try {
    const jsonObject = {
      type,
      callback
    };

    if (content) {
      jsonObject.content = content;
    }

    const obj = JSON.stringify(jsonObject);
    const encodedData = Base64.encode(obj);

    const deviceType = getMobileOperatingSystem();
    try {
      if (deviceType === "ios") {
        webkit.messageHandlers.callback.postMessage(encodedData);
      }
      if (deviceType === "android") {
        Android.postMessage(encodedData);
      }
    } catch (e) {

    }

  } catch (e) {

  }
}

const getMobileOperatingSystem = () => {
  try {
    const userAgent = navigator.userAgent || navigator.vendor || window.opera;
    if (/android/i.test(userAgent)) {
      return "android";
    } else if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
      return "ios";
    } else {
      return "ios";
    }
  } catch (error) {
    alert(error);
  }
}


var globalEval = function( data ) {
	rnotwhite = /\S/;
	if ( data && rnotwhite.test(data) ) {
		var head = document.getElementsByTagName("head")[0] || document.documentElement,
			script = document.createElement("script");

		script.type = "text/javascript";

		if ( jQuery.support.scriptEval ) {
			script.appendChild( document.createTextNode( data ) );
		} else {
			script.text = data;
		}
		head.insertBefore( script, head.firstChild );
		head.removeChild( script );
	}
}


if(document.URL.indexOf('http://localhost') > -1) {
	// devOnly();
} else {
	// sendToNative("getDecryptionKey", "setDecryptionKey", null);
	// devOnly();
}


function setDecryptionKey(res) {
	try {
		if(res) {
      const data = Base64.decode(res);
      const keyJson = data; //JSON.parse(data);
      const password = data; //keyJson.file_decryption_key;


			//UTIL
			decrypted = CryptoJS.AES.decrypt(utilEncData, password);
			decrypted = decrypted.toString(CryptoJS.enc.Utf8);
			globalEval(decrypted);

			// Dao
			decrypted = CryptoJS.AES.decrypt(daoEncData, password);
			decrypted = decrypted.toString(CryptoJS.enc.Utf8);
			globalEval(decrypted);

			var fileName = null;

			if(pageName === "card") {
				decrypted = CryptoJS.AES.decrypt(cardEncData, password);
				decrypted = decrypted.toString(CryptoJS.enc.Utf8);
				globalEval(decrypted);
				if(onCardPageLoad) {
					onCardPageLoad();
					if(LOAD_DATA) {
              loadDataAfter(LOAD_DATA);
              LOAD_DATA = null;
          }
				}
			} else if(pageName === "conf") {
				decrypted = CryptoJS.AES.decrypt(configEncData, password);
				decrypted = decrypted.toString(CryptoJS.enc.Utf8);
				globalEval(decrypted);

			} else if(pageName === "index") {
				decrypted = CryptoJS.AES.decrypt(indexEncData, password);
				decrypted = decrypted.toString(CryptoJS.enc.Utf8);
				globalEval(decrypted);
			}
		} else {
			sendToNative("closeFullPage", null, null);
		}
	} catch(e) {
		console.log('e => ',e);
		sendToNative("closeFullPage", null, null);
	}
}

function loadData(res) {
	// LOAD_DATA = res;
	// if(LOAD_DATA) {
        loadDataAfter(res);
    //     LOAD_DATA = null;
    // }

}
function devOnly() {
	var script = document.createElement("script");
	script.setAttribute("type", "text/javascript");
	script.setAttribute("src", "scripts/utility.js");
	document.getElementsByTagName("head")[0].appendChild(script);

	var script = document.createElement("script");
	script.setAttribute("type", "text/javascript");
	script.setAttribute("src", "scripts/dao.js");
	document.getElementsByTagName("head")[0].appendChild(script);

	var fileName = null;
	if(pageName === "card") {
		fileName = "card.js";
	} else if(pageName === "conf") {
		fileName = "configure.js";
	}else if(pageName === "index") {
		fileName = "index.js";
	}

	if(fileName) {
		var script = document.createElement("script");
		script.setAttribute("type", "text/javascript");
		script.setAttribute("src", "scripts/"+fileName);
		document.getElementsByTagName("head")[0].appendChild(script);
	}
}
