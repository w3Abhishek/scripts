
let DATA = {
    headers: clone(authHeaders),
    userNames: {
        senderName: '',
        sessionName: '',
        userName: ''
    },
    confData: []
};

$(document).ready(function() {
  onIndexPageLoad();
});

// Function that gets called from the HTML
function onIndexPageLoad() {
    try {
        $(".page-loader").hide();
        setDeviceRelatedCss(); // Apply styles for ios/android
        readDataFromURL();
    } catch (e) {
        alert("onIndexPageLoad" + e);
    }
}

//
function readDataFromURL() {
    try {
        const urlData = getUrlParamsInJson(window.location.search);

        log(urlData, "urlData");

        if (urlData['instanceid'] && urlData['messageid']) {

            DATA.instanceid = parseInt(urlData['instanceid']);
            DATA.messageid = urlData['messageid'];
            DATA.totalResponseUser = parseInt(urlData['totalResponseUser']) || 0;
            DATA.groupSize = parseInt(urlData['groupSize']) || 1;
            DATA.currentUserId = urlData['userId'];
            DATA.isAdmin = (urlData['isAdmin']==="true");
            DATA.groupUserData = [];

            if(DATA.isAdmin) {
                $("#adminOnly").show();
            }
            const timekey = `${DATA.instanceid}_time_${DATA.currentUserId}`;

            DATA.myResponseDateTime = getLocal(timekey, false);

            log(DATA, "INDEX_PAGE");

            sendToNative("getMultipleUserImageData", "currentUserImage", DATA.currentUserId);

            sendToNative("getSenderUserName", "handleUserName", null);

            //For dev only
            if (APP.ONWEB && APP.MODE !== "production") {

                DATA.userNames.senderName = "Test name";
                DATA.userNames.sessionName = "Session TEST";
                DATA.userNames.userName = "TEST";
                DATA.groupUserData = [{
                        name: "Chiran",
                        image: "assets/image/profile.png",
                        id: "1234"
                    },
                    {
                        name: "Manish",
                        image: "assets/image/profile.png",
                        id: "12345"
                    }
                ]
                generateListItem();
            }
        }
    } catch (e) {
        showAlert("readDataFromURL" + e);
    }
}

function currentUserImage(res) {
    try {
        if (res) {
            const imageData = res.split('|');
            $("#imageContainer").attr('src', 'data:image/jpeg;base64,' + imageData[1]);
        }
    } catch (e) {
        showAlert("handleProfilePic" + e);
    }
}

function handleUserName(res) {
    if (res) {
        try {
            const data = Base64.decode(res);
            DATA.userNames.senderName = data;
            sendToNative("getSessionName", "handleSessionName", null);
        } catch (e) {
            showAlert("handleUserName" + e);
        }
    }
}

function handleSessionName(res) {
    if (res) {
        try {
            const data = Base64.decode(res);
            DATA.userNames.sessionName = data;
            sendToNative("getUserName", "setUserName", null);
        } catch (e) {
            showAlert("handleSessionName" + e);
        }
    }
}

function setUserName(res) {
    if (res) {
        try {
            const data = Base64.decode(res);
            DATA.userNames.userName = data;
            sendToNative("getAuthToken", "handleAuthToken", "1");
        } catch (e) {
            showAlert("handleUserName" + e);
        }
    }
}

function handleAuthToken(res) {
    if (res) {
        try {
            const data = Base64.decode(res);
            DATA.headers.token = data;
            log(data, "handleAuthToken");
            sendToNative("getEncryptedValue", 'setInstanceId', DATA.instanceid.toString());
        } catch (e) {
            showAlert("handleAuthToken" + e);
        }
    }
}

function setInstanceId(res) {
    if (res) {
        try {
            DATA.headers.instanceid = res;
            log(res, "setInstanceId");
            generateListItem();
        } catch (e) {
            showAlert("handleAuthToken" + e);
        }
    }
}

function populateIndexPage() {
    try {
        // Render top section
        setText($("#senderName"), DATA.userNames.senderName);
        setText($("#groupName"), DATA.userNames.sessionName);
        setText($("#title-p-index"), DATA.confData.stringcol1);
        setText($("#note-p-index"), 'Due by ' + moment.unix(parseInt(DATA.confData.stringcol3)/1000).format('ddd D MMM, h:mm a'));
    } catch(e) {
        showAlert("populateIndexPage" + e);
    }
}

// This function is to fetch current user's response
function fetchUsersResponse(userId = DATA.currentUserId){

  const usersResponse = DATA.usersResponse;
  let i, matched = false;

  for(i = 0;i < usersResponse.length;i++) {
    if(userId == usersResponse[i].userId) {
      matched = true;
      break;
    }
  }

  if(!matched) {
    return null;
  }

  const userResponse = usersResponse[i];

  for (var property in userResponse.data) {
      if (userResponse.data.hasOwnProperty(property)) {
          if(userResponse.data[property] == 'true') {
            return DATA.items[property];
          }
      }
  }

};

// This function is to set the view for admin
function setAdminOnly() {
    $("#total-pepole-size-p-index").text(DATA.groupSize);
    if(DATA.topResponse === false) {
      $('#index-top-response').hide();
    } else {
        $("#index-top-response .common-text-div").text(DATA.topResponse);
    }

    populateResponses();
}

// Function to render individual response count
function populateResponses() {
  $('#index-all-responses').empty();
  DATA.counterItems.length > 0 && DATA.counterItems.map((item) => {
    var responseKey = item.key.split('_')[2];
    var text = DATA.items[responseKey];

    if(item.counter && parseInt(item.counter) > 0) {
      var str = `
          <div class="common-text-div row flex-row response-option">
            <div class="col-xs-2">${item.counter}</div>
            <div class="col-xs-8 response-option-text">${text}</div>
            <div class="col-xs-2">
                <i class="fa fa-angle-right right-arrow-div margin-for-itemwise-page-container"></i>
            </div>
          </div>`;
      $('#index-all-responses').append(str);
    }
  });

  (!DATA.counterItems.length) && $('#index-all-responses-header').hide()

};


// This function makes series of calls to populate the report page and other pages associated with report page
function generateListItem() {

    try {
        // Construct query to fetch the generic data table config information
        const query = Object.assign({}, defaultSelectData);

        query.where = {
            instanceid: DATA.instanceid,
            type: 'config'
        };
        let selectQuery = jsonString(makeSelectDataQuery(query));

        // This AJAX call is to fetch the data table's config data
        commonAjaxUtility(selectQuery, DATA.headers).then((selectQueryResult) => {

            if (selectQueryResult.result && selectQueryResult.result[0]) {

                let rData = selectQueryResult.result[0][0];

                DATA.confData = rData;
                DATA.items = splitItemData(DATA.confData.stringcol2);
                DATA.itemCount = Object.keys(DATA.items).length;

                const pollPermissions = DATA.confData.stringcol4.split(';');

                DATA.responseVisible = pollPermissions[0];

                DATA.editPoll = pollPermissions[1];

                // Populate the default report page
                populateIndexPage();

                // This AJAX call gets all responses of users for that instance
                getAllResponses();

                if(DATA.isAdmin || DATA.responseVisible == 'true') {

                    const query1 = JSON.stringify(getAllItemResponses(DATA.instanceid, DATA.itemCount));

                    // This AJAX call gets the number of times a particular choice was selected by user
                    commonAjaxUtility(query1, DATA.headers).then((selectCounterResult) => {

                        if (selectCounterResult.result && selectCounterResult.result[0]) {
                            DATA.counterItems = selectCounterResult.result[0];
                            DATA.topResponse = (DATA.counterItems.length > 0) && determineTopResponse();
                        }

                        setAdminOnly();

                    }, (selectCounterError) => {
                        log(selectCounterError, 'selectCounterError');
                    });
                }
            }
        }, (error) => {
            log(error, 'selectQueryError');
            //@POPUP
            showAlert(error);
        })
    } catch(e) {
        showAlert("generateListItem " + e);
    }
}

// Function that returns the top response out of all the poll choices
function determineTopResponse() {
  var highest = 0;
  const indexMax = DATA.counterItems.reduce((maxIndex, currentItem, currentIndex, items) => {
    return parseInt(currentItem.counter) > parseInt(items[maxIndex].counter) ? currentIndex : maxIndex
  }, 0);

  return DATA.items[parseInt(DATA.counterItems[indexMax].key.split('_')[2])];
}

function getAllResponses() {
    try {
        const query = Object.assign({}, defaultSelectData);
        query.where = {
            instanceid: DATA.instanceid,
            type: 'response'
        };
        const selectQuery = jsonString(makeSelectDataQuery(query));

        // AJAX call for getting all user responses for that poll
        commonAjaxUtility(selectQuery, DATA.headers).then((selectQueryResult) => {

            if (selectQueryResult.result && selectQueryResult.result[0]) {

                DATA.allResponse = selectQueryResult.result[0];

                const usersResponse = [];
                const tempUser = [];
                if (DATA.allResponse.length > 0) {

                    DATA.allResponse.map(function(r) {

                        if (!isEmptyObject(r) && r.stringcol4 && r.stringcol1) {
                            if (tempUser.indexOf(r.stringcol1) === -1) {
                                const userId = r.stringcol1;
                                tempUser.push(userId);
                                const data = splitItemData(r.stringcol4);
                                usersResponse.push({
                                    userId,
                                    data
                                });
                            }
                        }
                    });
                }

                DATA.usersResponse = usersResponse;

                $("#total-pepole-resposne-p-index").text(DATA.usersResponse.length);

                // Render user's response
                if (DATA.myResponseDateTime) {
                    const response = fetchUsersResponse();
                    $("#response-time-p-index").text("Your response: " + response);
                    $("#response-time-wrapper-index").show();

                    // If poll is editable, show the edit button else keep it hidden
                    if(DATA.editPoll == 'false') {
                      $('.btn-edit').show();
                    }
                } else {
                    if(new Date(parseInt(DATA.confData.stringcol3)) - new Date() > 0) {
                        $("#response-button-wrapper-index").show();
                    }
                }

                // Fetch details of users
                getRespondedUserDetails();
            }
        }, (selectQueryError) => {


        })
    } catch(e) {
        showAlert("getAllResponses "+e);
    }
}

let userIdForName = [];
let countUser = 0;
// Function to fetch details of the user from native app
function getRespondedUserDetails() {
  DATA.usersResponse.length > 0 &&  DATA.usersResponse.map(function(userData) {
    let userId = userData.userId;
    userIdForName.push(userId);
    sendToNative("getUserName", "setUserData", userId);
  });
}


function setUserData(res) {
    if (res) {
        try {
            const data = Base64.decode(res);
            let uid =userIdForName.shift();
            let temp = {
                name: data,
                image: "assets/image/profile.png",
                id: uid
            }
            
            DATA.groupUserData.push(temp);
            sendToNative("getMultipleUserImageData", "setUserImage", uid);
        } catch (e) {
            showAlert("handleUserName" + e);
        }
    }
}

function setUserImage(res) {
    if (res) {
        try {
            const userData = res.split('|');
            if(!isEmptyObject(userData) && userData.length === 2) {
                DATA.groupUserData.forEach(function(users) {
                if(users.id==userData[0]) {
                    users.image = 'data:image/jpeg;base64,' + userData[1]
                  }
                });
            }
        } catch (e) {
            showAlert("handleUserName" + e);
        }
    }
}

function addListUserHtml(list, count) {
    try {
        $("#selectedItemDetailsPage-list").html('');
        if (list && list.length > 0 && count > 0) {
            let html = '';
            list.forEach((data) => {
                const user = findInJson(DATA.groupUserData, data);

                if(!isEmptyObject(user)) {
                    html = `${html}<div class="container common-border-div">
                        <div class="row common-flex-styling">
                            <div class="col-xs-10 common-padding-for-report-view-page common-flex-styling">
                                <img id="imageContainer" class="pull-left profile-pic-div" src="${user.image}" />
                                <div class="common-text-div common-margin-between-div pull-left"> ${user.name} </div>
                            </div>
                        </div>
                    </div>`;
                }
            })
            $("#selectedItemDetailsPage-list").html(html);
        }
    } catch(e) {
        showAlert("addListUserHtml "+e);
    }

}

// Filter users by their poll choice
function filterUsersByResponse(users, text) {
  var filteredUsers = users.filter((user) => {
    if(fetchUsersResponse(user.userId).toLowerCase() == text.toLowerCase()) {
      return true;
    }
  });
  return filteredUsers;
}

$("#index-people-responses").click(function() {
    if (DATA.usersResponse.length > 0) {
        addListPeopleHtml(DATA.usersResponse);
        moveToPreviousPage(2);
    }
});

function addListPeopleHtml(list, container = "#respondent-list-wrapper") {
    let html = '';
    list.forEach((userData) => {
        const user = findInJson(DATA.groupUserData, userData.userId);
        const response = fetchUsersResponse(userData.userId);
        if(!isEmptyObject(user)) {
            let count = 0;
            for (let key in userData.data) {
                if (userData.data[key] == "true") {
                    count++;
                }
            };
            html = `${html}<div class="container common-border-div user-res-wrapper" data="${userData.userId}">
                    <div class="row common-flex-styling">
                        <div class="col-xs-12 common-padding-for-report-view-page">
                            <img id="imageContainer" class="pull-left profile-pic-div" src="${user.image}" />
                            <div class="pull-left margin-text-div">
                                <div class="common-text-div"> ${user.name}</div>
                                <div class="common-sub-text-div"> ${response} </div>
                            </div>
                        </div>
                    </div>
                </div>`;
        }
    });

    $(container).html(html);
}

$('#respondent-list-wrapper, #responseDetailsPage-items').on('click', '.user-res-wrapper', function(ev) {
    const userId = $(this).attr('data');
    const user = findInJson(DATA.groupUserData, userId);
    const html = getListOfItems(userId);
    if(!isEmptyObject(user)) {
        $("#respondentDetailsPage-header").text(user.name);
    }
    $('#respondentDetailsPage-items').html(html);

    if($(this).closest('#responseDetailsPage').length) {
      $('#respondentDetailsPage .fa-angle-left').attr('data-source', 5);
    } else {
      $('#respondentDetailsPage .fa-angle-left').attr('data-source', 2);
    }

    moveToPreviousPage(3);

});

$('#respondentDetailsPage .fa-angle-left').click(function() {
  var pageNo = parseInt($(this).attr('data-source'));
  moveToPreviousPage(pageNo);
});

function getListOfItems(userId) {
    let html = "";
    try {
        DATA.usersResponse.forEach((userData) => {
            if (userData.userId == userId) {
                for (let key in userData.data) {
                    let checked = '';

                    if (userData.data[key] == "true") {
                        checked = "checked";
                    }

                    const itemName = DATA.items[key];
                    html = `${html}<div class="container">
                            <div class="row">
                                <div class="col-xs-12 common-padding-for-report-view-page" data="${key}">
                                    <input type="checkbox" class="pull-left common-check-box-div " ${checked} disabled/>
                                    <div class="common-text-div margin-text-div pull-left">${itemName}</div>
                                </div>
                            </div>
                        </div>`;
                };
            }
        });
        return html;
    } catch(e) {
        return html;
    }
}

$("#respond-todo-btn").click(function() {
    try {
        const path = `configure.html?userRespond=true&instanceId=${DATA.instanceid}&messageid=${DATA.messageid}&userId=${DATA.currentUserId}`;
        sendToNative("openWebPage", "", path);
        // window.location = path;
    } catch (e) {
        alert("respondButtonClick" + e);
    }
});

$("#response-time-wrapper-index").click(function() {
    const user = findInJson(DATA.groupUserData, DATA.currentUserId);
    const html = getListOfItems(DATA.currentUserId);
    if(!isEmptyObject(user)) {
        $("#myDetailsPage-header").text(user.name);
    }
    $('#myDetailsPage-items').html(html);
    moveToPreviousPage(4);
});

$(document).on('click touchend', 'div.response-option', function() {

  let choice = $(this).find('.response-option-text').text();

  $('#responseDetailsPage-header').text('Replied ' + choice);
  if (DATA.usersResponse.length > 0) {
      addListPeopleHtml(filterUsersByResponse(DATA.usersResponse, choice), '#responseDetailsPage-items');
      moveToPreviousPage(5);
  }
});

$('.btn-edit').click(function(ev) {
  ev.preventDefault();
  ev.stopPropagation();
  try {
      const path = `configure.html?userRespond=true&instanceId=${DATA.instanceid}&messageid=${DATA.messageid}&userId=${DATA.currentUserId}`;
      sendToNative("openWebPage", "", path);
      // window.location = path;
  } catch (e) {
      alert("respondButtonClick" + e);
  }

});

// $('#respondentDetailsPage').on('click', '.fa-angle-left', function() {
//   if($(this).closest(''))
// });

function moveToPreviousPage(data = 0) {

    switch (data) {
        case 0:
            sendToNative("closeFullPage", null, null);
            break;
        case 1:
            hideAll();
            $("#reportViewPage").show(); // Initial report page
            break;
        case 2:
            hideAll();
            $("#respondentListpage").show(); // List of user's page with choices
            break;
        case 3:
            hideAll();
            $("#respondentDetailsPage").show(); // Users response page
            break;
        case 4:
            hideAll();
            $("#myDetailsPage").show(); // My response page
            break;
        case 5:
            hideAll();
            $('#responseDetailsPage').show();
            break;
        default:
            break;
    }
}

function hideAll() {
    $("#reportViewPage").hide();
    $("#myResponsePage").hide();
    $("#selectedItemDetailsPage").hide();
    $("#respondentListpage").hide();
    $("#respondentDetailsPage").hide();
    $("#myDetailsPage").hide();
    $("#responseDetailsPage").hide();
}
