authHeaders = {
    serialNumber: 1,
    token: 0,
    instanceid: 0
};

const CARD_DATA = {
    headers: clone(authHeaders),
    maxChoices: 2
};

var nativeCallDone = 0;
function viewWillAppear(){
    if(nativeCallDone == 0) {
        sendToNative("getCEPHHeader", "handleCEPHAuthHeaders", null); // 0 
    } else if(nativeCallDone == 1) {
        sendToNative("getGroupSize", "handleGroupSize", null); // 1
    } else if(nativeCallDone == 2) {
        sendToNative("getAuthToken", "handleAuthToken", "1");//2
    } else if(nativeCallDone == 3) {
        sendToNative("getEncryptedValue", 'setInstanceId', CARD_DATA.message.instanceid.toString()); //3
    } else if(nativeCallDone == 4){
        sendToNative('isAdmin', 'handleAdminConfirmation', null); //4
    }else if(nativeCallDone == 5){
         sendToNative('getMessageId', 'setMessageId', '0'); //5
    } else if(nativeCallDone == 6){
      populateCardPage();
    }
}

function onCardPageLoad() {
    try {
        setDeviceRelatedCss();

        //For dev only
        if (APP.ONWEB && APP.MODE !== "production") {
            const data = {
                "type": "config",
                "stringcol1": "Do you use JIO chat?",
                "stringcol2": "0=>Yes~@~1=>No~@~2=>Not%20sure",
                "stringcol3": "1631375238251",
                "stringcol4": "false;false",
                "stringcol5": "CEPH-a11-Z6yrIbu9270215318104261321531810508;CEPH-a11-Z6yrIbu9270215318104261321531810509;CEPH-a11-Z6yrIbu9270215318104261321531810510",
                "timestamp": "Thu Jun 28 13:15:24 IST 2018",
                "miniapptype": "POLL",
                "miniAppId": 6000000000897,
                "key": "2194_response",
                "counter": 0,
                "instanceid": 123667,
                "responses": [{"counter":"15","key":"123669_item_0"},{"counter":"15","key":"123669_item_1"},{"counter":"15","key":"123669_item_2"}]

            };
            CARD_DATA.messageid = "4E84297871D4580041181A9C95C156CC";
            CARD_DATA.groupSize = 4;
            CARD_DATA.currentUserId = 1234;
            CARD_DATA.message = data;
            CARD_DATA.message.stringcol2 = splitItemData(CARD_DATA.message.stringcol2);
            CARD_DATA.message.stringcol5 = CARD_DATA.message.stringcol5.split(';');
            CARD_DATA.CEPHAuthHeadersData =  {"token": "p5inoEBsp6x1bnjP9C1AGA;;","userid": "lJOafa3prt2k-k_hIfurXw;;"};
            CARD_DATA.isAdmin = true;
            CARD_DATA.cephBaseURL = "https://betanav.rsocial.net:8446/swift/v1/";
            populateCardPage();
        }
    } catch (e) {
        showAlert("onCardPageLoad" + e);
    }
}

// The main function to populate the card on chat window
function populateCardPage() {
  nativeCallDone++; 
    try {
        setText($("#cardHeaderName"), APP.WIDGET_NAME);

        setText($("#cardSubHeaderName"), CARD_DATA.message.stringcol1);

        const checkBoxOptions = CARD_DATA.message.stringcol4.split(';');

        // Either shows the time or if its closed
        $("#cardHeaderTimeRemainingParent").html(renderTimeRemaining(parseInt(CARD_DATA.message.stringcol3)));

        setText($("#cardHeaderDueTime"), `Due by ${moment.unix(parseInt(CARD_DATA.message.stringcol3)/1000).format('ddd D MMM, h:mm a')}`);

        const timekey = `${CARD_DATA.message.instanceid}_time_${CARD_DATA.currentUserId}`;

        CARD_DATA.myResponseDateTime = getLocal(timekey, false) ? getLocal(timekey, false) : null;

        // If user has responded to poll and responses can be made visible or its the user himself show it else render the options
        $('.cardChoicesDiv').empty();
        $('.cardResponsesDiv').empty();

        if(CARD_DATA.myResponseDateTime && (checkBoxOptions[0] == 'false' || CARD_DATA.isAdmin)) {
            renderPollResponses(CARD_DATA.message.stringcol2, CARD_DATA.message.responses);
        } else {
            renderPollChoices(CARD_DATA.message.stringcol2);
        }

        // Render the user response section if available
        const choicekey = `${CARD_DATA.message.instanceid}_choice_${CARD_DATA.currentUserId}`;

        if(getLocal(choicekey, false)) {
            $('#userResponseDiv').html(`Your response: <b>${sanitizeText(CARD_DATA.message.stringcol2[getLocal(choicekey, false)])}</b>`);
        }

        // Hide vote button section if poll has expired
        if(calculateTimeRemaning(parseInt(CARD_DATA.message.stringcol3)) < 0) {
          $('#markedPollButtonSection').hide();
        } else {
            // If member cannot change their vote and user has already voted, hide the vote button
            if(checkBoxOptions[1] == 'true' && CARD_DATA.myResponseDateTime) {
              $('#markedPollButtonSection').hide();
            } else {
              setText($("#markedPollButton"), CARD_DATA.myResponseDateTime ? 'CHANGE VOTE' : 'VOTE NOW');
            }
        }

        if(checkBoxOptions[0] == "false") {
          setText($('#choicesTitle'), CARD_DATA.myResponseDateTime ? 'Top Responses' : 'Choices');
        }

        if(CARD_DATA.message.stringcol5 && CARD_DATA.message.stringcol5.length == 0) {
          showContainer();
        }

        var ceph_url = CARD_DATA.cephBaseURL,
        promises = [],
        clusterCode,
        fullFileURL, imageData = [];

        for(let i = 0;i < CARD_DATA.maxChoices;i++) {
          clusterCode = CARD_DATA.message.stringcol5[i].split('-')[1];
          fullFileURL = (`${ceph_url}${clusterCode}/${CARD_DATA.message.stringcol5[i]}`).trim();
          promises.push(fetchFileFromCEPH(fullFileURL, CARD_DATA.CEPHAuthHeadersData));
        }

        Promise.all(promises).then((res) => {
          var promises2 = [];
          res.map((item) => {
            if(item.status == 200) {
              promises2.push(item.text());
            } else {
              imageData = [];
              throw 'Something went wrong';
            }
          });
          return Promise.all(promises2);
        }).then(datas => {
          imageData = [];
          datas.map((data) => {
            imageData.push(data);
          });
          renderImages(imageData);
          // Show the card after rendering the images
          showContainer();
        }).catch(error => {
          showContainer();
        });
    } catch (e) {
        showAlert("populateCardPage" + e);
    }
}

function showContainer() {
  $("#cardPageContainer").show(100, () => {
    sendToNative("setHeight","",document.documentElement.offsetHeight + '');
    $('body').css('visibility','visible');
  });
}

// Function to render the poll images
function renderImages(imageData) {
  var pollImages = $('.poll-image');
  for (let i = 0;i < pollImages.length;i++) {
    (imageData[i]) ? $(pollImages[i]).css({'background-image':`url(${imageData[i]})`,'width': '3.5rem','height': '3.5rem', 'min-width': '3.5rem'}) : '';
  }
}

// Get the time remaining in string format
function renderTimeRemaining(timeToEnd) {

  const timeRemaining = calculateTimeRemaning(timeToEnd);

  // If poll has expired, show as closed
  if(timeRemaining < 0) {
    return '<div id="cardHeaderPollClosed" class="pull-right" class="cardHeaderNameDiv">Closed</div>';
  }

  const numHoursRemaining = Math.ceil((timeRemaining)/(1000*60*60));
  const numDaysRemaining = Math.ceil(numHoursRemaining/24);
  const unitRemaining = (numHoursRemaining >= 24) ? numDaysRemaining : numHoursRemaining;
  let unit;

  if(numHoursRemaining >= 24) {
    unit = (numDaysRemaining == 1) ? 'day' : 'days';
  } else {
    unit = (numHoursRemaining == 1) ? 'hour' : 'hours';
  }

  return `<div id="cardHeaderTimeRemaining" class="pull-right" class="cardHeaderNameDiv">Ends in ${unitRemaining} ${unit}</div>`;
}

// Function to calculate number of milliseconds remaining
function calculateTimeRemaning(timeToEnd) {
  return (new Date(timeToEnd) - new Date());
}

// Function to render the poll choices
function renderPollChoices(jsonPollChoices) {

  const keys = Object.keys(jsonPollChoices);

  for(let i = 0;i < CARD_DATA.maxChoices;i++) {
    $('.cardChoicesDiv').append(renderPollText(sanitizeText(jsonPollChoices[keys[i]])));
  }

  // If choices are more than 2, show more choices
  if(keys.length > CARD_DATA.maxChoices) {
    $('.cardChoicesDiv').append('More choices...');
  }
}

// Render Poll Option
function renderPollText(choiceText) {
  return `<div class="row poll-choice">
  <div class="col-xs-12 commonPaddingForCardPage">

  <div class="commonTextDiv choiceDiv">
    <div class="poll-image"></div>
  <div>${choiceText}</div>
  </div>
  </div></div>`;
}

// Function to render the responses of poll
function renderPollResponses(jsonPollChoices, responses) {

  const keys = Object.keys(jsonPollChoices);

  // Compute total responses
  let totalResponses = 0;
  if(responses.length) {
    totalResponses = responses.reduce((accumulator, response) => ({
      counter: parseInt(accumulator.counter) + parseInt(response.counter)
    })).counter;
  }

  // Calculate percentage of responses
  responses.forEach((response) => {
    response.percentage = parseFloat(parseInt(response.counter)/totalResponses).toFixed(2)*100;
  });

  // Iterate over two of the poll choices and render them
  responses.slice(0,CARD_DATA.maxChoices).forEach((response, index) => {
    $('.cardResponsesDiv').append(renderPollResponse(jsonPollChoices[keys[index]], response));
  });

}

// Render Poll Option
function renderPollResponse(pollChoice, response){
  return `<div class="row poll-response">
  <div class="col-xs-12 commonPaddingForCardPage">
  <div class="row commonTextDiv">
  <div class="col-xs-10 response-div" style="overflow: hidden;text-overflow: ellipsis">
    <div class="poll-image"></div>
    ${pollChoice}
  </div>
  <div class="col-xs-2 responseTotalDiv">${response.counter}</div>
  </div>
  <div class="progressBarPoll" style="width:${response.percentage}%"></div>
  </div></div>`;

}


// This is the entry function that gets called from native apps
function loadDataAfter(response) {
    try {
        // Format the data first
        const dataReceived = Base64.decode(response);
        log(dataReceived, "loadData");
        const data = JSON.parse(dataReceived);
        let message = data[0][0];
        message.stringcol2 = splitItemData(message.stringcol2);
        message.stringcol5 = (message.stringcol5 && message.stringcol5.trim() !== '') ? message.stringcol5.split(';') : [];
        message.responses = formatResponses(message, data[1]);
        CARD_DATA.message = message;

        (message.stringcol5.length > 0) ? sendToNative("getCEPHDetails", "handleCEPHDetails", null) : sendToNative('getUserId', 'handleUserId', null);

    } catch (e) {
        showAlert("loadData" + e);
    }
}

/** Fetch CEPH details **/
function handleCEPHDetails(base64CEPHDetail) {
    try {
        var decryptedCEPHDetail = JSON.parse(Base64.decode(base64CEPHDetail));
        CARD_DATA.cephBaseURL = decryptedCEPHDetail.baseURL;
        CARD_DATA.clusterCode = decryptedCEPHDetail.clusterCode;
        sendToNative("getCEPHHeader", "handleCEPHAuthHeaders", null);
    } catch (e) {
        showAlert("handleCEPHDetails" + e);
    }
}

/*================ callback from native returning CEPH headers ================*/

function handleCEPHAuthHeaders(res) {
    try {
        var data = Base64.decode(res);
        CARD_DATA.CEPHAuthHeadersData = JSON.parse(data);
        nativeCallDone++;
        sendToNative('getUserId', 'handleUserId', null);
    } catch (e) {
        showAlert("handleCEPHAuthHeaders" + e);
    }
}

// Iterate over all choices and make sure they are present in the response. If not, add it.
function formatResponses(message, responses) {
  const options = message.stringcol2;
  let formattedResponse = [];
  let responseKey, isPresent;

  for (var property in options) {
      if (options.hasOwnProperty(property)) {
          isPresent = false;
          responseKey = message.instanceid + '_item_' + property;
          responses.forEach((response) => {
            if(response.key == responseKey) {
              formattedResponse.push(response);
              isPresent = true;
            }
          });

          if(!isPresent) {
            formattedResponse.push({"counter": "0","key": responseKey});
          }
      }
  }
  return formattedResponse;
};

// Function to store the user id
function handleUserId(res) {
    if (res) {
        try {
            const data = Base64.decode(res);
            CARD_DATA.currentUserId = data;
            log(data, "handleUserId");
            // This fetches the group size
            nativeCallDone++; //1
            sendToNative("getGroupSize", "handleGroupSize", null);
        } catch (e) {
            showAlert("handleUserId" + e);
        }
    }
}

// Function to store the group size
function handleGroupSize(res) {
    if (res) {
        try {
            const data = Base64.decode(res);
            CARD_DATA.groupSize = data;
            log(data, "handleGroupSize");
            nativeCallDone++; //2
            sendToNative("getAuthToken", "handleAuthToken", "1");
        } catch (e) {
            showAlert("handleGroupSize" + e);
        }
    }
}

function handleAuthToken(res) {
    if (res) {
        try {
            const data = Base64.decode(res);
            CARD_DATA.headers.token = data;
            log(data, "handleAuthToken");
            // Fetch the instance id of the card
            nativeCallDone++; //3
            sendToNative("getEncryptedValue", 'setInstanceId', CARD_DATA.message.instanceid.toString());
        } catch (e) {
            showAlert("handleAuthToken" + e);
        }
    }
}

// Function to set the instance id
function setInstanceId(res) {
    if (res) {
        try {
            const data = Base64.decode(res);
            CARD_DATA.headers.instanceid = data;
            log(data, "setInstanceId");
            // Fetch whether user is an admin for that card/instance id
            nativeCallDone++; //4
            sendToNative('isAdmin', 'handleAdminConfirmation', null);
        } catch (e) {
            showAlert("handleAuthToken" + e);
        }
    }
}

// Function to set whether the person is admin for that instance id
function handleAdminConfirmation(res) {
    if(res) {
        try {
            const myVal = Base64.decode(res);
            CARD_DATA.isAdmin = (myVal === 'true');
            nativeCallDone++; //5
            sendToNative('getMessageId', 'setMessageId', '0');
        } catch (e) {
            alert("handleAdminConfirmation" + e);
        }
    }
}

function setMessageId(res) {
    if (res) {
        try {
            const data = Base64.decode(res);
            CARD_DATA.messageid = data;
            log(data, "setMessageId");
            nativeCallDone++; //6
            populateCardPage();
        } catch (e) {
            showAlert("handleAuthToken" + e);
        }
    }
}

$("#card-upper-wrapper").click(function() {
    const path = `index.html?isAdmin=${CARD_DATA.isAdmin}&instanceid=${CARD_DATA.message.instanceid}&messageid=${CARD_DATA.messageid}&totalResponseUser=${CARD_DATA.message.counter}&groupSize=${CARD_DATA.groupSize}&userId=${CARD_DATA.currentUserId}`;
    if (APP.ONWEB && APP.MODE !== "production") {
        window.location = path;
    } else {
        sendToNative("openWebPage", "", path);
    }
});

function respondButtonClick() {
    try {
        const path = `configure.html?userRespond=true&instanceId=${CARD_DATA.message.instanceid}&messageid=${CARD_DATA.messageid}&userId=${CARD_DATA.currentUserId}`;
        if (APP.ONWEB && APP.MODE !== "production") {
            window.location = path;
        } else {
            sendToNative("openWebPage", "", path);
        }
    } catch (e) {
        alert("respondButtonClick" + e);
    }
}
