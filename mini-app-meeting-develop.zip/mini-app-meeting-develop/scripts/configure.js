let CONFIG_DATA = {
	messageId: UUID.randomUUIDHex(),
	instanceId: null,
	headerData: clone(authHeaders)
}

const onConfigurePageLoad = () => {
	try {
		if (isOnline()) {
			setDeviceRelatedCss();
			readDataFromURL();
			$("#inviteLocationDiv").click(function(){
				$('#LocationModal').modal('toggle');
			});
		} else {
			internetConnectionError();
		}
	} catch (e) {
		showAlert("onConfigurePageLoad" + e);
	}
}

const readDataFromURL = () => {
	try {
		const urlData = getUrlParamsInJson(window.location.search);
		CONFIG_DATA.instanceId = parseInt(urlData["instanceId"]);
		sendToNative('getUserId', 'handleUserId', null);
		if (APP.ONWEB && APP.MODE !== "production") {
			CONFIG_DATA.currentUserId = 100001;
		}
		if (CONFIG_DATA.instanceId) {
			sendToNative("getAuthToken", "handleAuthToken", "1");
		} else {
			showAlert("invalid instanceid");
		}
	} catch (e) {
		showAlert("readDataFromURL" + e);
	}
}

function handleUserId(res) {
	if (res) {
		try {
			const data = Base64.decode(res);
			CONFIG_DATA.currentUserId = data;
		} catch (e) {
			showAlert("handleUserId" + e);
		}
	}
}

function handleAuthToken(res) {
	try {
		const data = Base64.decode(res);
		CONFIG_DATA.headerData.token = data;
		sendToNative("getEncryptedValue", 'setInstanceId', CONFIG_DATA.instanceId.toString());
	} catch (e) {
		showAlert("handleAuthToken" + e);
	}
}

$("#durationTime").keypress(function (e) {
	if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
		$("#errmsg").html("Digits Only").show().fadeOut("slow");
		return false;
	} else if ((e.target.value + e.key) > 1440) {
		$("#errmsg").html("enter value less than 1440 mins").show();
		return false;
	}
});

$("#durationTime").keydown(function (e) {
	if (e.which == 8 || e.which == 48 || e.which == 46) {
		$("#errmsg").html("");
	}
});

function setInstanceId(res) {
	try {
		if (res) {
			CONFIG_DATA.headerData.instanceid = res;
		} else {
			showAlert("setInstanceId error" + res);
		}
	} catch (e) {
		showAlert("setInstanceId API error" + e);
	}
}

function sendRequestButtonClick() {
	if (APP.ONWEB && APP.MODE !== "production") {
		addMeeting();
	} else {
		const jsonToSend = jsonString({             
			"instanceId" : CONFIG_DATA.instanceId,
			"needNotification" : false,
			"notificationMessage": false,
			"miniAppName": "Meeting"
		});
		sendToNative("instanceConfirmationSuccess", "handleInstanceConfirmation", jsonToSend);
	}
}

function handleInstanceConfirmation(res) {
	if (res) {
		try {
			const result = Base64.decode(res);
			if (result == "true") {
				addMeeting();
			} else {
				showAlert("Network error");
			}
		} catch (e) {
			showAlert("handleInstanceConfirmation" + e);
		}
	} else {
		showAlert("handleInstanceConfirmation failed");
	}
}

function goToLocation() {
	$("#meetingContainer").hide();
	$("#inputLocation").show();
}

function backToMeeting() {
	$("#inputLocation").hide();
	$("#meetingContainer").show();
}

function enableSaveBtn(event){
	let input = event.value;
	if(input) $(".fa-check").removeClass("fade-btn");
	else $(".fa-check").addClass("fade-btn");
}

function saveUserLocation(){
	const loc = $("#userLocation").val();
	if(!loc) return;
	backToMeeting();
	$("#inviteLocationDiv").html(loc);
}
	
const addMeeting = () => {
	try {
		const inviteTitleText = $("#inviteTitleDiv").val();
		const calendarText = $("#meetingDateTimePicker").val();
		const durationTime = $("#durationTime").val();
		const inviteLocationText = $("#inviteLocationDiv").val();
		const inviteAgendaText = $("#inviteAgendaDiv").val();

		let errorMsg = '';

		if (isEmpty(inviteTitleText)) {
			errorMsg = "Please enter title for meeting \n";
		}

		if (isEmpty(calendarText)) {
			errorMsg = errorMsg + "Please enter date \n";
		}

		if (isEmpty(durationTime)) {
			errorMsg = errorMsg + "Please enter duration time \n";
		}

		if (isEmpty(inviteLocationText)) {
			errorMsg = errorMsg + "Please enter location \n";
		}

		if (isEmpty(inviteAgendaText)) {
			errorMsg = errorMsg + "Please enter Agenda \n";
		}

		if (isEmpty(errorMsg) && CONFIG_DATA.instanceId) {
			let sendData = clone(insertQueryData);
			sendData.data.instanceid = CONFIG_DATA.instanceId;
			sendData.data.stringcol1 = CONFIG_DATA.currentUserId.toString();
			sendData.data.stringcol4 = inviteTitleText;
			sendData.data.stringcol5 = calendarText;
			sendData.data.stringcol6 = inviteTime;
			sendData.data.stringcol7 = durationTime;
			sendData.data.stringcol8 = inviteLocationText;
			sendData.data.stringcol9 = inviteAgendaText;
			sendData.data.stringcol10 = ($("#checkBoxDiv").prop("checked")).toString();
			//sendData.data.timestamp = new Date();
			sendData.data.timestamp = moment().format("YYYY-MM-DD HH:mm:ss");
			const insertDataTableQuery = insertQueryBuilder(sendData, false);
			const insertQuery = {
				input: jsonString([insertDataTableQuery])
			}
			log(insertQuery, 'insertQuery');

			commonAjaxUtility(jsonString(insertQuery), CONFIG_DATA.headerData).then((insertQueryResult) => {
				log(insertQueryResult, 'insertQueryResult');
				commonAjaxUtility(jsonString(makeSendMessageQuery(CONFIG_DATA.instanceId, CONFIG_DATA.messageId)), CONFIG_DATA.headerData).then((makeSendMessageResult) => {
					log(makeSendMessageResult, 'makeSendMessageResult');
					$.alert("", "Configuration saved successfully", function () {
						sendToNative("closeFullPage", null, null);
					});

				}, (makeSendMessageError) => {
					log(makeSendMessageError, 'makeSendMessageError');
					if (makeSendMessageError.status === 200) {
						showAlert("Configuration save successfully");
						sendToNative("closeFullPage", null, null);
					}
				});
			}, (insertQueryError) => {
				log(insertQueryError, 'insertQueryError');
				errorPopUP();
			});
		} else {
			$.alert("", errorMsg);
		}

	} catch (e) {
		showAlert("sendRequestButtonClick" + e);
	}
}

const closeCurrentWebPage = () => {
	try {
		sendToNative("closeFullPage", null, null);
	} catch (e) {
		showAlert("closeCurrentWebPage" + e);
	}
}
