const sendToNative = (type, callback, content) => {
  try {
    const jsonObject = {
      type,
      callback
    };

    if (!isEmpty(content)) {
      jsonObject.content = content;
    }

    const obj = jsonString(jsonObject);
    const encodedData = Base64.encode(obj);

    const deviceType = getMobileOperatingSystem();
    try {
      if (deviceType === "ios") {
        webkit.messageHandlers.callback.postMessage(encodedData);
      }
      if (deviceType === "android") {
        Android.postMessage(encodedData);
      }
    } catch (e) {
      //alert("sendToNative" + e);
    }

  } catch (e) {
    //alert("sendToNative" + e);
  }
}

const setDeviceRelatedCss = () => {
  try {
    var currentDevice = getMobileOperatingSystem();
    var body = document.body;
    body.classList.add(currentDevice);
  } catch (e) {
    alert("setDeviceRelatedCss" + e);
  }
}

const getMobileOperatingSystem = () => {
  try {
    const userAgent = navigator.userAgent || navigator.vendor || window.opera;
    if (/android/i.test(userAgent)) {
      return "android";
    } else if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
      return "ios";
    } else {
      return "ios";
    }
  } catch (error) {
    showAlert(error);
  }
}

const isEmpty = (data) => {
  if (data && data.trim() !== '') {
    return false;
  }
  return true;
}

const isEmptyObject = (obj) => {
  return jQuery.isEmptyObject(obj);
}

const showAlert = (data) => {
  if (APP.MODE !== 'production') {
    if (typeof data === 'object') {
      alert(jsonString(data));
    } else {
      alert(data);
    }
  }
}

const alertMessgage = (text) =>{

};

const setLocal = (key, data) => {
  if (typeof data === 'object') {
    localStorage.setItem(key, JSON.stringify(data));
  } else {
    localStorage.setItem(key, data);
  }

}

const getLocal = (key, isObject = true) => {
  if (isObject) {
    return JSON.parse(localStorage.getItem(key) || '{}')
  } else {
    return localStorage.getItem(key) || null;
  }
}

const deleteLocal = (key) => {
  localStorage.removeItem(key);
}

const jsonString = (obj) => {
  return JSON.stringify(obj);
}

const clone = (obj, obj1 = {}) => {
  return Object.assign({}, obj, obj1);
}

const getUrlParamsInJson = (url) => {
  var arrayData = [];
  url.replace('?', '').split('&').map(function (values) {
    var urlData = values.split('=');
    arrayData[urlData[0]] = urlData[1];
  })
  return arrayData;
}

const isOnline = () => {
  return navigator.onLine;
}

const removeHtml = (string) => {
  if (string) {
    return string.replace(/(<([^>]+)>)/ig, "");
  }
  return string;
}

const setText = (element, string) => {
  element.text(removeHtml(string));
}


const getMultipleArrayData = (rData, last = true, isC) => {
  if (rData) {
    rData = rData.slice(1);
    rData = rData.substring(0, rData.length - 1);
    rData = rData.split(APP.ARRAY_SPLIT);
    if (last) {
      rData = rData[rData.length - 1];
      rData = rData.split(APP.ARRAY_SPLIT_ITEM);
      return rData;
    } else {
      let returnData = [];
      rData.map((k) => {
        const itemData = k.split(APP.ARRAY_SPLIT_ITEM);
        let tempJson = {};
        itemData.map(function (q, i) {
          tempJson[i] = q.trim()
        });
        returnData.push(tempJson);
      })
      return returnData;
    }
  }
  return {};
}

const getSingleArrayData = (rData, sendAarry) => {
  if (rData) {
    let returnData = [];
    rData = rData.slice(1);
    rData = rData.substring(0, rData.length - 1);
    rData = rData.split(APP.ARRAY_SPLIT_ITEM);
    if (sendAarry) {
      return rData;
    } else {
      let tempJson = {};
      rData.map(function (q, i) {
        tempJson[i] = q.trim()
      });
      returnData.push(tempJson);
      return returnData;
    }
  }
  return [];
}

const getResultDataInJSON = (data, last = true, sendAarry = true) => {
  if (data) {
    if (data.indexOf(APP.ARRAY_SPLIT) > -1) {
      return getMultipleArrayData(data, last);
    } else {
      return getSingleArrayData(data, sendAarry);
    }
  }
  return {};
}

const splitItemData = (data) => {
    //
  let returnData = {};
  if (data) {
    const items = data.split(APP.CONCAT_ITEM);
    items.map(function (item) {
      const itemData = item.split(APP.CONCAT_ITEM_VALUE);
      if (itemData.length === 2) {
        const key = itemData[0].trim();
        // const val = decodeURI(itemData[1].trim());
        const val = decodeURI(itemData[1].replace(APP.REPLACE_ARRAY_SPLIT_ITEM, APP.ARRAY_SPLIT_ITEM));
        returnData = clone(returnData, {
          [key]: val
        })
      }
    });
  }
  return returnData;
}

const getItemResponsed = (data) => {
  try {
    let count = 0;
    for (let key in data) {
      if (data[key] && data[key][1] && parseInt(data[key][1]) > 0) {
        count++;
      }
    }
    return count;
  } catch (e) {
    showAlert("getItemResponsed" + e)
  }
}

const findInJson = (data, searchtext) => {
  let result = {};
  data.find(item => {
    for (let key in item) {
      if (item[key] === searchtext) {
        result = item;
      }
    }
  });

  return result;
}

const errorPopUP = () => {
    $.alert("", "Something went wrong", function () {
        sendToNative("closeFullPage", null, null);
    });
}

function UUID() {}
UUID.hexChar = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"];

UUID.randomUUID = function () {
  randomBytes = new Int8Array(16);
  for (var index = 0; index < 16; index++) {
    randomBytes[index] = Math.random() * 10000;
  }
  return randomBytes;
};

UUID.randomUUIDHex = function () {
  var byteArray = UUID.randomUUID();
  var str = "";
  for (var index = 0; index < byteArray.length; index++) {
    var b = byteArray[index];
    var val = UUID.hexChar[(b >> 4) & 0x0f] + UUID.hexChar[b & 0x0f];
    str += val;
  }
  return str;
}

const shortMonthsToNumber = {
  'Jan': '01',
  'Feb': '02',
  'Mar': '03',
  'Apr': '04',
  'May': '05',
  'Jun': '06',
  'Jul': '07',
  'Aug': '08',
  'Sep': '09',
  'Oct': '10',
  'Nov': '11',
  'Dec': '12'
};

const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function parseTime(value) {
  try {
    var time = value,
      hour,
      minute,
      second,
      millis = '',
      delimited,
      timeArray;

    if (time.indexOf('.') !== -1) {
      delimited = time.split('.');
      time = delimited[0];
      millis = delimited[delimited.length - 1];
    }
    timeArray = time.split(':');
    if (timeArray.length === 3) {
      hour = timeArray[0];
      minute = timeArray[1];
      second = timeArray[2].replace(/\s.+/, '').replace(/[a-z]/gi, '');
      time = time.replace(/\s.+/, '').replace(/[a-z]/gi, '');
      return {
        time: time,
        hour: hour,
        minute: minute,
        second: second,
        millis: millis
      };
    }

    return {
      time: '',
      hour: '',
      minute: '',
      second: '',
      millis: ''
    };
  } catch (e) {
    showAlert("parseTime " + e);
  }
}

const parseDate = (value) => {
  try {
    parsedDate = {};
    if (value) {
      values = value.split(' ');

      parsedDate.year = values[5];
      parsedDate.month = shortMonthsToNumber[values[1]];
      parsedDate.dayOfMonth = values[2];
      parsedDate.time = parseTime(values[3]);
      parsedDate.date = new Date(parsedDate.year, parsedDate.month - 1, parsedDate.dayOfMonth, parsedDate.time.hour, parsedDate.time.minute, parsedDate.time.second, parsedDate.time.millis);
    }
    return parsedDate;
  } catch (e) {
    showAlert("parseDate " + e);
  }

}