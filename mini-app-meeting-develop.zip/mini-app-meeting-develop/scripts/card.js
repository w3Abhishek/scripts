authHeaders = {
	serialNumber: 3,
	token: 0,
	instanceid: 0
};

const CARD_DATA = {
	headers: clone(authHeaders),
};


const onCardPageLoad = () => {
	try {
		setDeviceRelatedCss();
		if (APP.ONWEB && APP.MODE !== "production") {
			let data = null;
			const iid = 3097;
			commonAjaxUtility(jsonString(makeCardQueryDev(iid))).then(res => {
				console.log('res => ', res);
				data = res.result;
				data.instanceid = iid;
				CARD_DATA.messageid = "52746A55A81D2097719018945F83596F";
				CARD_DATA.groupSize = 4;
				CARD_DATA.currentUserId = 1000071012;
				CARD_DATA.message = data;
				CARD_DATA.isAdmin = false;
				setData();
			});
		}
	} catch (e) {
		showAlert("onCardPageLoad" + e);
	}
}

var nativeCallDone = 0;
function viewWillAppear(){
    if(nativeCallDone == 0) {
       sendToNative('getUserId', 'handleUserId', null);
    } else if(nativeCallDone == 1) {
        sendToNative("getGroupSize", "handleGroupSize", "");
    } else if(nativeCallDone == 2) {
        sendToNative("getAuthToken", "handleAuthToken", "1");
    } else if(nativeCallDone == 3) {
        sendToNative("getEncryptedValue", 'setInstanceId', CARD_DATA.message.instanceid.toString());
    } else if(nativeCallDone == 4){
        sendToNative('isAdmin', 'handleAdminConfirmation', null);
    } else if(nativeCallDone == 5){
        sendToNative('getMessageId', 'setMessageId', '0');
    } else if(nativeCallDone == 6){
    	setData();
    }
}

function setData() {
	nativeCallDone++;
	CARD_DATA.autoSelect = false;
	//Conf Data 
	if (!isEmptyObject(CARD_DATA.message) && !isEmptyObject(CARD_DATA.message["0"]) && !isEmptyObject(CARD_DATA.message["0"][CARD_DATA.message["0"].length - 1])) {
		CARD_DATA.confData = CARD_DATA.message["0"][CARD_DATA.message["0"].length - 1];
	}
	if (CARD_DATA.confData.stringcol1) {
		CARD_DATA.senderId = CARD_DATA.confData.stringcol1;
	} else {
		CARD_DATA.senderId = CARD_DATA.currentUserId;
	}

	// Total response
	if (!isEmptyObject(CARD_DATA.message) && !isEmptyObject(CARD_DATA.message["1"]) && !isEmptyObject(CARD_DATA.message["1"][0])) {
		CARD_DATA.counter = CARD_DATA.message["1"][0]['counter'];
	} else {
		CARD_DATA.counter = 0;
	}

	// Item respones
	CARD_DATA.responseItem = [];
	if (!isEmptyObject(CARD_DATA.message) && !isEmptyObject(CARD_DATA.message["2"])) {

		CARD_DATA.message["2"].forEach((data) => {
			CARD_DATA.responseItem[data.key] = data.counter;
		})
	}

	CARD_DATA.itemPrefix = CARD_DATA.message.instanceid + '_item_';

	//All responses
	CARD_DATA.allCounterResponses = [];
	if (!isEmptyObject(CARD_DATA.message) && !isEmptyObject(CARD_DATA.message["2"])) {
		CARD_DATA.allCounterResponses = CARD_DATA.message["2"];
	}

	CARD_DATA.noOfPeopleResponded = null;
	CARD_DATA.currentSelected = null;
	
	//get current user response
	if (!isEmptyObject(CARD_DATA.message) && !isEmptyObject(CARD_DATA.message["3"])) {
		CARD_DATA.myResponseJson = CARD_DATA.message["3"];
		CARD_DATA.noOfPeopleResponded = CARD_DATA.message["3"].length;
		CARD_DATA.myResponseJson.forEach((data) => {
			const uid = parseInt(data.stringcol1);
			if (CARD_DATA.currentUserId == uid) {
				if (!isEmpty(data.stringcol4)) {
					log("currentSelected", data.stringcol4);
					CARD_DATA.currentSelected = data.stringcol4;
				}
			}
		});
		if (CARD_DATA.currentSelected) {
			CARD_DATA.autoSelect = true;
			$("[data=" + CARD_DATA.currentSelected + "]").click();
		}
	}

	fillAllData();
}

function loadData(res) {
	try {
		const dataReceived = Base64.decode(res);
		const data = JSON.parse(dataReceived);
		CARD_DATA.message = data;
		setData();
		nativeCallDone++;//1
		sendToNative('getUserId', 'handleUserId', null);
	} catch (e) {
		showAlert("loadData" + e);
	}
}

function fillAllData() {
	setText($("#cardHeaderName"), CARD_DATA.confData.stringcol2);
	setText($("#cardSubHeaderName"), CARD_DATA.confData.stringcol4);
	setText($("#details-meeting"), CARD_DATA.confData.stringcol9);

	if (CARD_DATA.isAdmin) {
		$("#responseStatusSection").text("People are yet to respond.");
		$("#buttonContainerDiv").hide();
		$("#adminTextTypeDiv").show();
	} else {
		if (isEmpty(CARD_DATA.currentSelected)) {
			$("#responseStatusSection").text("Are you attending?");
			$("#progressStatusDiv").hide();
		} else {
			setCardAttending();
			$("#progressStatusDiv").show();
		}
		$("#buttonContainerDiv").show();
		$("#adminTextTypeDiv").hide();
	}

	calculateTime();
}

function handleUserId(res) {
	try {
		if (res) {
			const data = Base64.decode(res);
			CARD_DATA.currentUserId = data;
			nativeCallDone++;//2
			sendToNative("getGroupSize", "handleGroupSize", "");
		} else {
			showAlert("userid not proper");
		}
	} catch (e) {
		showAlert("handleUserId", e);
	}
}

function handleGroupSize(res) {
	try {
		if (res) {
			const data = Base64.decode(res);
			CARD_DATA.groupSize = (parseInt(data) - 1);
			nativeCallDone++;//3
			sendToNative("getAuthToken", "handleAuthToken", "1");
		} else {
			showAlert("groupsize not proper");
		}
	} catch (e) {
		showAlert("handleGroupSize" + e);
	}
}

function handleAuthToken(res) {
	if (res) {
		try {
			const data = Base64.decode(res);
			CARD_DATA.headers.token = data;
			nativeCallDone++;//3
			sendToNative("getEncryptedValue", 'setInstanceId', CARD_DATA.message.instanceid.toString());
		} catch (e) {
			showAlert("handleAuthToken" + e);
		}
	}
}

function setInstanceId(res) {
	if (res) {
		try {
			const data = res;
			CARD_DATA.headers.instanceid = data;
			nativeCallDone++;//4
			sendToNative('isAdmin', 'handleAdminConfirmation', null);
		} catch (e) {
			showAlert("handleAuthToken" + e);
		}
	}
}

function handleAdminConfirmation(res) {
	try {
		if (res) {
			const myVal = Base64.decode(res);
			CARD_DATA.isAdmin = (myVal === 'true');
			nativeCallDone++;//5
			sendToNative('getMessageId', 'setMessageId', '0');
		} else {
			showAlert("isAdmin not proper");
		}
	} catch (e) {
		showAlert("handleAdminConfirmation" + e);
	}
}

function setMessageId(res) {
	try {
		if (res) {
			const data = Base64.decode(res);
			CARD_DATA.messageid = data;
			setData();
			nativeCallDone++;
		} else {
			showAlert("message id not proper");
		}
	} catch (e) {
		showAlert("handleAuthToken" + e);
	}
}

function calculateTime() {
	const confDate = CARD_DATA.confData.stringcol5 + " " + CARD_DATA.confData.stringcol6;
	const confDateTime = moment(confDate);
	if (moment(confDateTime).isValid() && CARD_DATA.confData.stringcol7) {
		const duration = parseInt(CARD_DATA.confData.stringcol7);
		CARD_DATA.startTime = confDateTime.toDate();
		CARD_DATA.endTime = moment(CARD_DATA.startTime).add(duration, 'minutes').toDate();
		let currentTimeStatus = moment(CARD_DATA.startTime).fromNow();
		setText($("#card-res-time"), confDateTime.format("DD-MM-YYYY HH:MM A"));
		if ((CARD_DATA.endTime - moment()) < 0) {
			setText($("#timeRemainingDiv"), "Meeting Over");
			$("#timeRemainingDiv").css("background-color", "lightgray");
			$("#buttonContainerDiv").hide();
		} else if ((CARD_DATA.endTime - moment()) > 0 && (CARD_DATA.startTime - moment()) < 0) {
			setText($("#timeRemainingDiv"), "Going On");
		} else if ((CARD_DATA.startTime - moment()) > 0) {
			currentTimeStatus = "Due" + " " + currentTimeStatus;
			setText($("#timeRemainingDiv"), currentTimeStatus);
		}
	}
}

function setCardAttending() {
	if (CARD_DATA.currentSelected && CARD_DATA.groupSize && CARD_DATA.groupSize > 0 && CARD_DATA.responseItem) {
		const yesData = parseInt(CARD_DATA.responseItem[CARD_DATA.itemPrefix + "0"]);
		const noData = parseInt(CARD_DATA.responseItem[CARD_DATA.itemPrefix + "1"]);
		const mayBeData = parseInt(CARD_DATA.responseItem[CARD_DATA.itemPrefix + "2"]);
		CARD_DATA.total = ((yesData ? yesData : 0) + (noData ? noData : 0) + (mayBeData ? mayBeData : 0));
		//if (CARD_DATA.total <= CARD_DATA.groupSize) {
			$('#progress-yes').css("width", `${percentage(yesData, CARD_DATA.groupSize)}%`);
			$('#progress-no').css("width", `${percentage(noData, CARD_DATA.groupSize)}%`);
			$('#progress-maybe').css("width", `${percentage(mayBeData, CARD_DATA.groupSize)}%`);
			const element = $('#responseStatusSection');
			const message = `${yesData} of ${CARD_DATA.groupSize} people attending`;
			setText(element, message);
		// } else {
		// 	console.log("Data Error");
		// }
	}
}

function percentage(partialValue, totalValue) {
	return (100 * partialValue) / totalValue;
}

$("#card-upper-wrapper").click(function () {
	moveToReportView();
});

$(".color-btn").click(function () {
	const haveActive = $(this).hasClass('active');
	const data = $(this).attr('data');
	if (!haveActive) {
		$(".color-btn").removeClass("active");
		$(this).addClass("active");
	} else {
		$(this).removeClass("active");
	}
	const selectedData = $("#buttonContainerDiv").find(".color-btn.active").attr("data") || "";

	const queryData = [];
	//Add response 
	let resData = clone(insertQueryData);
	resData.data.instanceid = CARD_DATA.message.instanceid;
	resData.data.type = APP.RESPONSE;
	resData.data.stringcol1 = CARD_DATA.currentUserId.toString();
	resData.data.stringcol4 = selectedData;
	resData.data.timestamp = new Date();
	const resDataQuery = insertQueryBuilder(resData, false);

	

	//Add counter if selectedAny
	let addCounter = null;
	if (!isEmpty(selectedData)) {
		const keyAdd = CARD_DATA.itemPrefix + selectedData;
		addCounter = updateCounter(keyAdd, "+1");
	}

	queryData.push(resDataQuery);

	// updateCounter (remove prec counter)
	if(CARD_DATA.currentSelected) {
		const keyRemove = CARD_DATA.itemPrefix + CARD_DATA.currentSelected;
		const removePrevCounter = updateCounter(keyRemove, "-1");
		queryData.push(removePrevCounter);
	}
	
	if (addCounter) {
		queryData.push(addCounter);
	}

	const insertQuery = {
		input: jsonString(queryData)
	}

	if (!CARD_DATA.autoSelect) {
		commonAjaxUtility(jsonString(insertQuery), CARD_DATA.headers).then((insertQueryResult) => {
			console.log('insertQueryResult => ', insertQueryResult);
			commonAjaxUtility(jsonString(makeSendMessageQuery(CARD_DATA.message.instanceid, CARD_DATA.messageid, true)), CARD_DATA.headers).then((makeSendMessageResult) => {
				if (APP.ONWEB && APP.MODE !== "production") {
					location = document.URL;
				} else {
					var path = document.URL.split("?");
					path = "card.html?"+path[1];
					sendToNative("openWebPage", "", path);
				}
			}, error => {
				console.log('makeSendMessageQuery => ', error);
			})
		}, insertQueryError => {
			console.log('insertQueryError => ', insertQueryError);
		});
	}
	CARD_DATA.autoSelect = false;
});

const moveToReportView = () => {
	try {
		const path = `index.html?isAdmin=${CARD_DATA.isAdmin}&instanceid=${CARD_DATA.message.instanceid}&messageid=${CARD_DATA.messageid}&totalSum=${CARD_DATA.total}&groupSize=${CARD_DATA.groupSize}&userId=${CARD_DATA.currentUserId}&senderId=${CARD_DATA.senderId}&currentSelected=${CARD_DATA.currentSelected}`;
		if (APP.ONWEB && APP.MODE !== "production") {
			window.location = path;
		} else {
			sendToNative("openWebPage", "", path);
		}
	} catch (e) {
		showAlert("moveToReportViewPage" + e);
	}
}
