let DATA = {
	headers: clone(authHeaders),
	userNames: {
		senderName: '',
		sessionName: '',
		userName: ''
	}
};

function onIndexPageLoad() {
	if (isOnline()) {
		try {
			$(".page-loader").hide();
			setDeviceRelatedCss();
			readDataFromURL();
		} catch (e) {
			alert("onIndexPageLoad" + e);
		}
	} else {
		$.alert("", "No internet connection", function () {
			sendToNative("closeFullPage", null, null);
		});
	}
}

function readDataFromURL() {
	try {
		const urlData = getUrlParamsInJson(window.location.search);
		DATA.autoSelect = false;
		if (urlData['instanceid'] && urlData['messageid']) {
			DATA.instanceid = parseInt(urlData['instanceid']);
			DATA.messageid = urlData['messageid'];
			DATA.totalSum = parseInt(urlData['totalSum']) || 0;
			DATA.groupSize = parseInt(urlData['groupSize']) || 1;
			DATA.currentUserId = urlData['userId'];
			DATA.senderId = urlData['senderId'];
			DATA.isAdmin = (urlData['isAdmin'] === "true");
			DATA.currentSelected = urlData['currentSelected'] == "null" ? null : urlData['currentSelected'];

			DATA.itemPrefix = DATA.instanceid + '_item_';
			DATA.groupUserData = [];
			if (DATA.isAdmin) {
				$("#adminOnly").show();
				$("#userOnly").hide();
				setAdminOnly();
			}
			if (!isEmpty(DATA.currentSelected)) {
				DATA.autoSelect = true;
				$("[data=" + DATA.currentSelected + "]").click();
			}

			sendToNative("getMultipleUserImageData", "currentUserImage", DATA.senderId);
			sendToNative("getSenderUserName", "handleUserName", null);
			sendToNative("getApiVersion", "getApiVersion", null);

			//For dev only
			if (APP.ONWEB && APP.MODE !== "production") {
				DATA.userNames.senderName = "Test name";
				DATA.userNames.sessionName = "Session TEST";
				DATA.userNames.userName = "TEST";
				DATA.groupUserData = [{
						name: "Kumar",
						image: "assets/image/profile.png",
						id: "100001"
                    },
					{
						name: "Manish",
						image: "assets/image/profile.png",
						id: "1000001274"
                    }
                ]
				generateListItem();
			}
		}
	} catch (e) {
		showAlert("readDataFromURL" + e);
	}
}

$(".color-btn").click(function () {
	const haveActive = $(this).hasClass('active');
	const data = $(this).attr('data');
	if (!haveActive) {
		$(".color-btn").removeClass("active");
		$(this).addClass("active");
	} else {
		$(this).removeClass("active");
	}
	const selectedData = $("#buttonContainerDiv").find(".color-btn.active").attr("data") || "";

	const queryData = [];
	//Add response 
	let resData = clone(insertQueryData);
	resData.data.instanceid = DATA.instanceid;
	resData.data.type = APP.RESPONSE;
	resData.data.stringcol1 = DATA.currentUserId.toString();
	resData.data.stringcol4 = selectedData;
	resData.data.timestamp = new Date();
	const resDataQuery = insertQueryBuilder(resData, false);

	// updateCounter (remove prec counter)
	const keyRemove = DATA.itemPrefix + DATA.currentSelected;
	const removePrevCounter = updateCounter(keyRemove, "-1");

	//Add counter if selectedAny
	let addCounter = null;
	if (!isEmpty(selectedData)) {
		const keyAdd = DATA.itemPrefix + selectedData;
		addCounter = updateCounter(keyAdd, "+1");
	}

	queryData.push(resDataQuery);
	queryData.push(removePrevCounter);
	if (addCounter) {
		queryData.push(addCounter);
	}

	const insertQuery = {
		input: jsonString(queryData)
	}

	if (!DATA.autoSelect) {
		commonAjaxUtility(jsonString(insertQuery), DATA.headers).then((insertQueryResult) => {
			console.log('insertQueryResult => ', insertQueryResult);
			commonAjaxUtility(jsonString(makeSendMessageQuery(DATA.instanceid, DATA.messageid, true)), DATA.headers).then((makeSendMessageResult) => {

				DATA.currentSelected = !isEmpty(selectedData) ? selectedData : null;

			}, error => {
				console.log('makeSendMessageQuery => ', error);
			})
		}, insertQueryError => {
			console.log('insertQueryError => ', insertQueryError);
		});
	}
	DATA.autoSelect = false;
});

function currentUserImage(res) {
	try {
		if (res) {
			const imageData = res.split('|');
			$("#imageContainer").attr('src', 'data:image/jpeg;base64,' + imageData[1]);
		}
	} catch (e) {
		showAlert("handleProfilePic" + e);
	}
}

function getApiVersion(res) {
	if (res) {
		try {
			const data = Base64.decode(res);
			DATA.apiVersion = data;
		} catch (e) {
			showAlert("getApiVersion" + e);
		}
	}
}

function handleUserName(res) {
	if (res) {
		try {
			const data = Base64.decode(res);
			DATA.userNames.senderName = data;
			sendToNative("getSessionName", "handleSessionName", null);
		} catch (e) {
			showAlert("handleUserName" + e);
		}
	}
}

function handleSessionName(res) {
	if (res) {
		try {
			const data = Base64.decode(res);
			DATA.userNames.sessionName = data;
			sendToNative("getUserName", "setUserName", null);
		} catch (e) {
			showAlert("handleSessionName" + e);
		}
	}
}

function setUserName(res) {
	if (res) {
		try {
			const data = Base64.decode(res);
			DATA.userNames.userName = data;
			sendToNative("getAuthToken", "handleAuthToken", "1");
		} catch (e) {
			showAlert("handleUserName" + e);
		}
	}
}

function handleAuthToken(res) {
	if (res) {
		try {
			const data = Base64.decode(res);
			DATA.headers.token = data;
			log(data, "handleAuthToken");
			sendToNative("getEncryptedValue", 'setInstanceId', DATA.instanceid.toString());
		} catch (e) {
			showAlert("handleAuthToken" + e);
		}
	}
}

function setInstanceId(res) {
	if (res) {
		try {
			DATA.headers.instanceid = res;
			log(res, "setInstanceId");
			generateListItem();
		} catch (e) {
			showAlert("handleAuthToken" + e);
		}
	}
}

function populateIndexPage() {
	try {
		setText($("#senderName"), DATA.userNames.senderName);
		setText($("#groupName"), DATA.userNames.sessionName);
		if (DATA.configData) {
			const confDate = DATA.configData.stringcol5 + " " + DATA.configData.stringcol6;
			const confDateTime = moment(confDate);
			setText($("#meeting-title"), DATA.configData.stringcol4);
			setText($("#meeting-detail"), DATA.configData.stringcol9);
			setText($("#date-time-div"), confDateTime.format("DD-MM-YYYY HH:MM A"));
		}

	} catch (e) {
		showAlert("populateIndexPage" + e);
	}
}

function setAdminOnly() {

	$("#NoOfUserResponded").text(DATA.totalSum);
	$("#totalCountOfUser").text(DATA.groupSize);
}

function generateListItem() {
	try {
		const query = Object.assign({}, defaultSelectData);
		query.where = {
			instanceid: DATA.instanceid,
			type: 'config'
		};
		let selectQuery = jsonString(makeSelectDataQuery(query));
		log(selectQuery, 'selectQuery');
		commonAjaxUtility(selectQuery, DATA.headers).then((selectQueryResult) => {
			const result = selectQueryResult['result'];
			// Set Config Data
			if (!isEmptyObject(result)) {
				DATA.configData = null;
				if (!isEmptyObject(result["0"])) {
					DATA.configData = !isEmptyObject(result["0"][result["0"].length - 1]) ? result["0"][result["0"].length - 1] : null;
				}
			}
			populateIndexPage();

			if (DATA.isAdmin) {
				const query1 = JSON.stringify(getAllItemResponses(DATA.instanceid));
				commonAjaxUtility(query1, DATA.headers).then((selectCounterResult) => {
					const result = selectCounterResult['result'];
					DATA.itemResponseCount = [];
					console.log(result);
					if (result && result[0]) {
						result[0].forEach((data) => {
							DATA.itemResponseCount[data.key] = data.counter;
						});
						getAllResponses();
					}
				}, (selectCounterError) => {
					log(selectCounterError, 'selectCounterError');
				});
			}
		}, (selectQueryError) => {
			log(selectQueryError, 'selectQueryError');
			//@POPUP
			showAlert(error);
		})
	} catch (e) {
		showAlert("generateListItem " + e);
	}
}

function getAllResponses() {
	try {
		const query = Object.assign({}, defaultSelectData);
		query.where = {
			instanceid: DATA.instanceid,
			type: 'response',
		};
		query.fields = ["stringcol4", "stringcol1"];
		const selectQuery = jsonString(makeSelectDataQuery(query));
		commonAjaxUtility(selectQuery, DATA.headers).then((selectQueryResult) => {
			console.log('selectQueryResult => ', selectQueryResult);
			const result = selectQueryResult['result'];
			DATA.allResponse = null;
			if (!isEmptyObject(result)) {
				DATA.allResponse = result["0"];
			}

			const tempUser = [];
			const usersResponse = [];
			if (!isEmptyObject(DATA.allResponse)) {
				DATA.allResponse.forEach(user => {
					const userId = user.stringcol1;
					if (tempUser.indexOf(userId) === -1) {
						tempUser.push(userId);
						const data = user.stringcol4;
						usersResponse.push({
							userId,
							data
						});
					}
				});
			}
			DATA.usersResponse = usersResponse;
			if(DATA.usersResponse && DATA.usersResponse.length) {
				$("#NoOfUserResponded").text(DATA.usersResponse.length);
			}
			setItemResponses();
			getRespondedUserDetails();
		}, (selectQueryError) => {
			log(selectQueryError, 'selectQueryError')
		})
	} catch (e) {
		showAlert("getAllResponses " + e);
	}
}

let userIdForName = [];

function getRespondedUserDetails() {
	if (!isEmptyObject(DATA.usersResponse)) {
		DATA.usersResponse.forEach(function (userData) {
			const userId = userData.userId;
			userIdForName.push(userId);
			sendToNative("getUserName", "setUserData", userId.toString());
		});
	}
}


function setUserData(res) {
	if (res) {
		try {
			if (!isEmptyObject(userIdForName)) {
				const id = userIdForName.shift();
				const data = Base64.decode(res);
				const temp = {
					name: data,
					image: "assets/image/profile.png",
					id: id
				}
				DATA.groupUserData.push(temp);
				sendToNative("getMultipleUserImageData", "setUserImage", id);
			}
		} catch (e) {
			showAlert("handleUserName" + e);
		}
	}
}

function setUserImage(res) {
	if (res) {
		try {
			const userData = res.split('|');
			if (!isEmptyObject(userData) && userData.length === 2) {
				DATA.groupUserData.forEach(function (users) {
					if (users.id == userData[0]) {
						users.image = 'data:image/jpeg;base64,' + userData[1]
					}
				});
			}
		} catch (e) {
			showAlert("handleUserName" + e);
		}
	}
}

function setItemResponses() {
	let yes = 0;
	let no = 0;
	let maybe = 0;
	let html = "";
	for (let key in meetingButtons.data) {
		let count = 0;
		if (!isEmptyObject(DATA.itemResponseCount) && !isEmpty(DATA.itemResponseCount[DATA.itemPrefix + key])) {
			count = parseInt(DATA.itemResponseCount[DATA.itemPrefix + key]);
		}
		const name = meetingButtons.data[key];
		let arrow = "";
		let className = "";
		if (count > 0) {
			arrow = `<div class="col-xs-2 common-padding-for-report-view-page">
                        <i class="fa fa-angle-right right-arrow-div margin-for-itemwise-page-container"></i>
                    </div>`;

			className = "itemWiseClick";
		}
		html = `${html}<div class="row ${className}" data="${key}">
                    <div class="col-xs-10 common-padding-for-report-view-page page-header-style-div">
                        <div class="common-text-div pull-left">${count}</div>
                        <div class="common-sub-text-div colorBlackDiv pull-left common-margin-between-div">
                            ${name}
                        </div>
                    </div>
                    ${arrow}
                </div>`;
	}
	$("#itemsCountData").html(html);
}

$(document).on("touchstart click", ".itemWiseClick", function () {
	const item = $(this).attr("data");
	if (!isEmpty(item)) {
		moveToPreviousPage(3);
		$("#memberYesResponsePage-header").text(meetingButtons.data[item]);
		addListUserHtml(item);
	}
});

function addListUserHtml(item) {
	try {
		html = "";
		DATA.usersResponse.forEach(function (data) {
			const user = findInJson(DATA.groupUserData, data.userId);
			if (!isEmptyObject(user) && data.data == item) {
				html = `${html}<div class="container common-border-div">
                        <div class="row">
                            <div class="col-xs-12 common-flex-styling common-padding-for-report-view-page">
                                <img id="imageContainer" class="pull-left profile-pic-div" src="${user.image}" />
                                <div class="pull-left common-margin-between-div common-text-div">
                                    ${user.name}
                                </div>
                            </div>
                        </div>
                    </div>`;
			}
		});
		$("#itemWiseMembers").html(html);
	} catch (e) {
		showAlert("addListUserHtml " + e);
	}

}

$("#Insights-click").click(function () {
	if (!isEmptyObject(DATA.usersResponse)) {
		moveToPreviousPage(2);
		addListPeopleHtml(DATA.usersResponse);
	}
});

function addListPeopleHtml(list) {
	let html = '';
	list.forEach((userData) => {
		const user = findInJson(DATA.groupUserData, userData.userId);
		if (!isEmptyObject(user)) {
			const selectType = meetingButtons.data[userData.data];
			html = `${html}<div class="container common-border-div user-res-wrapper" data="${userData.userId}">
                    <div class="row common-flex-styling">
                        <div class="col-xs-10 common-padding-for-report-view-page">
                            <img id="imageContainer" class="pull-left profile-pic-div" src="${user.image}" />
                            <div class="pull-left margin-text-div">
                                <div class="common-text-div"> ${user.name}</div>
                                <div class="common-sub-text-div"> ${selectType} </div>
                            </div>
                        </div>
                    </div>
                </div>`;
		}
	});

	$("#userListResponses").html(html);
}

function moveToPreviousPage(data = 0) {
	switch (data) {
		case 0:
			sendToNative("closeFullPage", null, null);
			break;
		case 1:
			hideAll();
			$("#reportViewPage").show();
			break;
		case 2:
			hideAll();
			$("#memberResponsePage").show();
			break;
		case 3:
			hideAll();
			$("#memberYesResponsePage").show();
			break;
		default:
			break;
	}
}

function hideAll() {
	$("#reportViewPage").hide();
	$("#memberResponsePage").hide();
	$("#memberYesResponsePage").hide();
}
