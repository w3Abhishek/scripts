var authHeaders = {
	serialNumber: 3,
	token: 0,
	instanceid: 0
};

var defaultData = {
	ONWEB: document.URL.indexOf('/Documents/MiniApps') > -1 ? false : true,
	NAME: 'MEETING',
	VERSION: '0.0.1',
	MODE: 'production',
	WIDGET_NAME: 'Meeting Invite',
	BASE_URL: {
		dev: 'http://ec2-13-127-57-219.ap-south-1.compute.amazonaws.com:9999/genericservice/query/exec',
		preprod: 'https://betaexplore.rsocial.net:8104/genericservice/query/exec',
		production: 'https://pp.jiochat.com/genericservice/query/exec'
	},
	TYPE_INSERT: 'insert',
	TYPE_UPDATE: 'update',
	TYPE_SELECT: 'select',
	TYPE_SEND_MESSAGE: 'sendMessage',
	TABLE_DATA: 'miniapp.genericdatatable',
	TABLE_COUNTER: 'miniapp.genericcountertable',
	TIME: 'serverTime',
	CONFIG: 'config',
	RESPONSE: 'response',
	CONCAT_ITEM: '~@~',
	CONCAT_ITEM_VALUE: '=>',
	ARRAY_SPLIT: '][',
	ARRAY_SPLIT_ITEM: ',',
	REPLACE_ARRAY_SPLIT_ITEM: "~_~"

};

var APP = Object.freeze(defaultData);

var TABLE_MAPPING = {
	"instanceid": "instanceid",
	'type': 'config',
	"miniapptype": "appName",
	'stringcol1': 'title',
	'stringcol2': 'items',
	'stringcol3': 'notes',
	'stringcol4': 'cardHeader',
	'stringcol5': '0',
	'stringcol6': '0',
	'stringcol7': '0',
	'stringcol8': '0',
	'stringcol9': '0',
	'stringcol10': '0',
	'timestamp': 'serverTime',
};

var meetingButtons = {
	data: {
		0: 'Yes',
		1: 'No',
		2: 'MayBe'
	},
	count: 3
}

var counterTableInsert = {
	"type": APP.TYPE_UPDATE,
	"table": APP.TABLE_COUNTER,
	"data": {
		"key": null,
		"counter": null
	}
};

var insertQueryData = {
	"type": APP.TYPE_INSERT,
	"table": APP.TABLE_DATA,
	"data": {
		"instanceid": 0,
		"type": APP.CONFIG,
		"miniapptype": APP.NAME,
		"stringcol1": '',
		"stringcol2": APP.WIDGET_NAME,
		"stringcol3": '',
		"timestamp": APP.TIME
	}
};

var sendMessageData = {
	input: {
		"type": APP.TYPE_SEND_MESSAGE,
		"update": false,
		"messageId": '',
		"miniAppType": APP.NAME,
		"instanceId": 0,
		"fields": []
	}
};

var defaultCounterData = {
	"type": APP.TYPE_UPDATE,
	"table": APP.TABLE_COUNTER,
	"data": {
		"counter": 0,
	},
	"where": null
};

var defaultSelectData = {
	table: APP.TABLE_DATA,
	type: APP.TYPE_SELECT,
	fields: Object.keys(TABLE_MAPPING),
	where: null
};
var logData = [];

var logItem = {
	type: 'API',
	data: {},
	status: true,
	result: ''
};

let tempData = null;
var log = (result, type = 'API', data = {}, status = true) => {
	let lItem = clone(logItem);
	lItem.result = result;
	lItem.type = type;
	lItem.data = data;
	lItem.status = status;
	logData.push(lItem);
};

var getAllItemResponses = (instanceid, count = meetingButtons.count, withRoot = true, isStringify = true) => {
	var counterTableQuery = clone(defaultSelectData);
	counterTableQuery.table = APP.TABLE_COUNTER;
	if (count > 0) {
		let whereIn = "key in (";
		for (let i = 0; i < count; i++) {
			whereIn = whereIn + "'" + instanceid + "_item_" + i + "',";
		}
		whereIn = whereIn.substring(0, whereIn.length - 1) + " )";
		console.log('whereIn => ', whereIn);
		counterTableQuery.whereIn = whereIn;
	}
	counterTableQuery.fields = ["key", "counter"];
	return makeSelectDataQuery(counterTableQuery, withRoot, isStringify);
};

var getUserAndConfigQuery = (instanceId, userId) => {
	let data = [];
	let selectQuery = clone(defaultSelectData);
	selectQuery.where = {
		instanceid: instanceId,
		type: "response",
		stringcol1: userId
	};

	let query1 = makeSelectDataQuery(selectQuery, false, false);

	let selectQuery2 = Object.assign({}, defaultSelectData);
	selectQuery2.where = {
		instanceid: instanceId,
		type: 'config'
	};
	query2 = makeSelectDataQuery(selectQuery2, false, false);

	data.push(query2);
	data.push(query1);

	let query = {
		input: jsonString(data)
	};
	return jsonString(query);
};

var makeCardQueryDev = (instanceid) => {
	let data = [];
	//Get Conf data
	let dataTableQuery = clone(defaultSelectData);
	dataTableQuery.where = {
		instanceid: instanceid,
		type: APP.CONFIG
	};
	let dataTableSelectQuery = makeSelectDataQuery(dataTableQuery, false, false);
	//Get Response Data
	let dataTableQueryRes = clone(defaultSelectData);
	dataTableQueryRes.fields = ["stringcol4", "stringcol1"];
	dataTableQueryRes.where = {
		instanceid: instanceid,
		type: APP.RESPONSE
	};
	let dataTableSelectQueryRes = makeSelectDataQuery(dataTableQueryRes, false, false);
	//Get response counter data
	let counterTableQuery = clone(defaultSelectData);
	counterTableQuery.table = APP.TABLE_COUNTER;
	counterTableQuery.where = {
		key: instanceid + "_response"
	};
	counterTableQuery.fields = ["key", "counter"];
	let counterTableSelectQuery = makeSelectDataQuery(counterTableQuery, false, false);

	//Get All item counter data
	let allOtherResponse = getAllItemResponses(instanceid, meetingButtons.count, false, false);

	data.push(dataTableSelectQuery);

	data.push(counterTableSelectQuery);

	data.push(allOtherResponse);

	data.push(dataTableSelectQueryRes);

	query = {
		input: jsonString(data)
	}
	return query;
};
var makeSendMessageQuery = (instanceid, messageId, isUpadate = false) => {
	let data = [];

	//Get Conf data
	let dataTableQuery = clone(defaultSelectData);
	dataTableQuery.where = {
		instanceid: instanceid,
		type: APP.CONFIG
	};
	let dataTableSelectQuery = makeSelectDataQuery(dataTableQuery, false, false);
	//Get Response Data
	let dataTableQueryRes = clone(defaultSelectData);
	dataTableQueryRes.fields = ["stringcol4", "stringcol1"];
	dataTableQueryRes.where = {
		instanceid: instanceid,
		type: APP.RESPONSE
	};
	let dataTableSelectQueryRes = makeSelectDataQuery(dataTableQueryRes, false, false);
	//Get response counter data
	let counterTableQuery = clone(defaultSelectData);
	counterTableQuery.table = APP.TABLE_COUNTER;
	counterTableQuery.where = {
		key: instanceid + "_response"
	};
	counterTableQuery.fields = ["key", "counter"];
	let counterTableSelectQuery = makeSelectDataQuery(counterTableQuery, false, false);

	//Get All item counter data
	let allOtherResponse = getAllItemResponses(instanceid, meetingButtons.count, false, false);

	data.push(dataTableSelectQuery);

	data.push(counterTableSelectQuery);

	data.push(allOtherResponse);

	data.push(dataTableSelectQueryRes);

	let query = sendMessageQueryBulder(instanceid, messageId, isUpadate, data);

	return query;
};

var sendMessageQueryBulder = (instanceid, messageId, isUpadate = false, data = []) => {
	let sendMessageQuery = clone(sendMessageData);
	sendMessageQuery.input.fields = data;
	sendMessageQuery.input.update = isUpadate;
	sendMessageQuery.input.messageId = messageId;
	sendMessageQuery.input.instanceId = instanceid;
	let queryData = {
		input: jsonString([sendMessageQuery.input])
	};
	return queryData;
};

var makeSelectDataQuery = (data = {}, withRoot = true, isStringify = true) => {
	let selectQuery = null;
	if (isEmptyObject(data)) {
		selectQuery = clone(defaultSelectData);
		return selectQueryBuilder(selectQuery, withRoot, isStringify);
	} else {
		selectQuery = clone(data);
		if (!isEmptyObject(data.where)) {
			console.log('data.where => ', data.where);
			let whereClouse = "";
			for (let key in data.where) {
				if (isEmpty(whereClouse)) {
					if (key === 'instanceid') {
						whereClouse = key + "=" + data.where[key];
					} else {
						whereClouse = key + "='" + data.where[key] + "'";
					}
				} else {
					if (key === 'instanceid') {
						whereClouse = whereClouse + " and " + key + "=" + data.where[key];
					} else {
						whereClouse = whereClouse + " and " + key + "='" + data.where[key] + "'";
					}
				}
			}
			selectQuery.where = whereClouse;
		}
		if (data.whereIn) {
			selectQuery.where = data.whereIn;
			delete selectQuery.whereIn;
		}

	}
	return selectQueryBuilder(selectQuery, withRoot, isStringify);
};

var selectQueryBuilder = (selectData = defaultSelectData, withRoot = true, isStringify = true) => {
	let returnData = clone(selectData);
	if (!returnData.where) {
		delete returnData.where;
	}
	let data = null;
	if (withRoot) {
		data = {
			input: isStringify ? jsonString([returnData]) : returnData
		}
	} else {
		data = isStringify ? jsonString(returnData) : returnData
	}
	return data;
};

var insertQueryBuilder = (queryData = insertQueryData, withRoot = true) => {
	let query = {
		type: queryData.type,
		table: queryData.table
	};

	if (queryData.where) {
		query.where = queryData.where;
	}
	if (queryData.tableType) {
		query.tableType = queryData.tableType;
	}

	let colFieldsValues = getFieldValue(queryData.data);
	let returnValue = null;
	if (withRoot) {
		returnValue = {
			input: jsonString([clone(query, colFieldsValues)])
		}
	} else {
		returnValue = clone(query, colFieldsValues);
	}
	return returnValue;
};

var updateCounter = (key, counter = 0, withRoot = false) => {
	let counterData = clone(defaultCounterData);
	counterData.data = {
		"counter": counter
	};
	counterData.where = "key='" + key + "'";
	counterData.tableType = "counter";
	let counterInsertQuery = insertQueryBuilder(counterData, withRoot);
	return counterInsertQuery;
};

var getFieldValue = (data) => {
	let returnValue = {
		fields: [],
		values: []
	};
	for (let key in data) {
		returnValue.fields.push(key);
		returnValue.values.push(data[key]);
	}
	return returnValue;
};

var callAPI = (data, headers = authHeaders, url = APP.BASE_URL[APP.MODE], type = 'POST', dataType = 'json', contentType = 'application/json') => {
	console.log('data => ', data);
	console.log('authHeaders => ', authHeaders);
	console.log('APP.BASE_URL[APP.MODE] => ', APP.BASE_URL[APP.MODE]);
	return $.ajax({
		type: type,
		url: url,
		headers: headers,
		data: data,
		dataType: dataType,
		contentType: contentType,
		beforeSend: function () {
			$.showPreloader(" ");
		},
		complete: function () {
			$.hidePreloader();
		},
	});
};



var commonAjaxUtility = (data, headers = authHeaders) => {
	return new Promise(function (resolve, reject) {
		if (isOnline()) {
			callAPI(data, headers).then(function (result) {
				log(result, 'API', data, true);
				resolve(result);
			}, function (error) {
				log(error, 'API', data, false);
				if (error.status == 403 || error.status == 401) {
					tempData = null;
					tempData = {
						data: data,
						headers: headers
					};
					sendToNative("getAuthToken", "handleAuthTokenOnAuthFail", "1");
				} else {
					reject(error);
				}
			});
		} else {
			$.alert("", "No internet connection", function () {
				sendToNative("closeFullPage", null, null);
			});
		}
	});
};


function handleAuthTokenOnAuthFail(res) {
	try {
		var data = Base64.decode(res);
		tempData.headers.token = data;
		commonAjaxUtility(tempData.data, tempData.headers);
	} catch (e) {
		showAlert("handleAuthToken" + e);
	}
};
